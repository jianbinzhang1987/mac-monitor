#![no_std]

// This file exists to enable the library target.
