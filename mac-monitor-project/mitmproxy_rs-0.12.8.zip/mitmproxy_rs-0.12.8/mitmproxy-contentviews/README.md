# mitmproxy-contentviews

This crate contains various contentviews for mitmproxy,
exposed to Python via [mitmproxy-rs/src/contentviews.rs].
For additional documentation, see https://docs.mitmproxy.org/dev/addons/contentviews/.

[mitmproxy-rs/src/contentviews.rs]: ../mitmproxy-rs/src/contentviews.rs
