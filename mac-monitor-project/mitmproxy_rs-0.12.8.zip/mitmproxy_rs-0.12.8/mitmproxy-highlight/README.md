# mitmproxy-highlight

This crate contains the syntax highlighting backend for mitmproxy and mitmdump,
utilizing [tree-sitter].
This functionality is exposed to Python via [mitmproxy-rs/src/syntax_highlight.rs].

[tree-sitter]: https://tree-sitter.github.io/tree-sitter/
[mitmproxy-rs/src/syntax_highlight.rs]: ../mitmproxy-rs/src/syntax_highlight.rs