# mitmproxy_rs

This package contains mitmproxy's Rust bits.

[![dev documentation](https://shields.mitmproxy.org/badge/docs-Python%20API-blue.svg)](https://mitmproxy.github.io/mitmproxy_rs/)

https://github.com/mitmproxy/mitmproxy_rs
