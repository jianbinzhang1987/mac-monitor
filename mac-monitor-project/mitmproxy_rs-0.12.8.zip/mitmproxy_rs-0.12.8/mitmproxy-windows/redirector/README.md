# windows-redirector

`windows-redirector.exe` spawns with elevated privileges and 
redirects traffic to mitmproxy via a Windows named pipe.
